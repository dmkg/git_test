﻿
namespace PassManageApp
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_PassManage = new System.Windows.Forms.Label();
            this.lbl_UserName = new System.Windows.Forms.Label();
            this.lbl_UserPassword = new System.Windows.Forms.Label();
            this.txtb_Username = new System.Windows.Forms.TextBox();
            this.txtb_UserPassword = new System.Windows.Forms.TextBox();
            this.btn_UserLogin = new System.Windows.Forms.Button();
            this.lbl_MessageLogin = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_PassManage
            // 
            this.lbl_PassManage.AutoSize = true;
            this.lbl_PassManage.Location = new System.Drawing.Point(331, 21);
            this.lbl_PassManage.Name = "lbl_PassManage";
            this.lbl_PassManage.Size = new System.Drawing.Size(76, 15);
            this.lbl_PassManage.TabIndex = 0;
            this.lbl_PassManage.Text = "Pass Manage";
            // 
            // lbl_UserName
            // 
            this.lbl_UserName.AutoSize = true;
            this.lbl_UserName.Location = new System.Drawing.Point(78, 148);
            this.lbl_UserName.Name = "lbl_UserName";
            this.lbl_UserName.Size = new System.Drawing.Size(60, 15);
            this.lbl_UserName.TabIndex = 1;
            this.lbl_UserName.Text = "Username";
            // 
            // lbl_UserPassword
            // 
            this.lbl_UserPassword.AutoSize = true;
            this.lbl_UserPassword.Location = new System.Drawing.Point(78, 201);
            this.lbl_UserPassword.Name = "lbl_UserPassword";
            this.lbl_UserPassword.Size = new System.Drawing.Size(57, 15);
            this.lbl_UserPassword.TabIndex = 2;
            this.lbl_UserPassword.Text = "Password";
            // 
            // txtb_Username
            // 
            this.txtb_Username.Location = new System.Drawing.Point(78, 166);
            this.txtb_Username.Name = "txtb_Username";
            this.txtb_Username.Size = new System.Drawing.Size(129, 23);
            this.txtb_Username.TabIndex = 3;
            // 
            // txtb_UserPassword
            // 
            this.txtb_UserPassword.Location = new System.Drawing.Point(78, 219);
            this.txtb_UserPassword.Name = "txtb_UserPassword";
            this.txtb_UserPassword.Size = new System.Drawing.Size(129, 23);
            this.txtb_UserPassword.TabIndex = 4;
            // 
            // btn_UserLogin
            // 
            this.btn_UserLogin.Location = new System.Drawing.Point(78, 269);
            this.btn_UserLogin.Name = "btn_UserLogin";
            this.btn_UserLogin.Size = new System.Drawing.Size(129, 23);
            this.btn_UserLogin.TabIndex = 5;
            this.btn_UserLogin.Text = "Login";
            this.btn_UserLogin.UseVisualStyleBackColor = true;
            this.btn_UserLogin.Click += new System.EventHandler(this.btn_UserLogin_Click);
            // 
            // lbl_MessageLogin
            // 
            this.lbl_MessageLogin.AutoSize = true;
            this.lbl_MessageLogin.Location = new System.Drawing.Point(78, 318);
            this.lbl_MessageLogin.Name = "lbl_MessageLogin";
            this.lbl_MessageLogin.Size = new System.Drawing.Size(0, 15);
            this.lbl_MessageLogin.TabIndex = 6;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(294, 450);
            this.Controls.Add(this.lbl_MessageLogin);
            this.Controls.Add(this.btn_UserLogin);
            this.Controls.Add(this.txtb_UserPassword);
            this.Controls.Add(this.txtb_Username);
            this.Controls.Add(this.lbl_UserPassword);
            this.Controls.Add(this.lbl_UserName);
            this.Controls.Add(this.lbl_PassManage);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Login to Pass Manage ";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_PassManage;
        private System.Windows.Forms.Label lbl_UserName;
        private System.Windows.Forms.Label lbl_UserPassword;
        private System.Windows.Forms.TextBox txtb_Username;
        private System.Windows.Forms.TextBox txtb_UserPassword;
        private System.Windows.Forms.Button btn_UserLogin;
        private System.Windows.Forms.Label lbl_MessageLogin;
    }
}

