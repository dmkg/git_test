﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace PassManageApp
{
    
    class User
    {
        public static string fPath = @"C:\Users\DarrenG\Documents\PassManage\users\";        
        static string userName;
        static Dictionary<int, Account> dictUserAccs;
        static int[] favorites;
        
        public User() { }

        public User(string _userName)
        {
            userName = UserName;
            dictUserAccs = DictUserAccs;
            
        }
        
                  
        

        public static string UserName { get { return userName; }  set{ userName = value; } }
        public static Dictionary<int, Account> DictUserAccs { get { return dictUserAccs; } set { dictUserAccs = value; }  }
        //public string GetUserName(string userName) { return UserName; }
    }
}
