﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PassManageApp
{
    class Account
    {
        
        string accName;
        string accuserName;
        string accEmail;
        string accPass;
        string accHint;
        string accImage;

        public Account( string _accName ,string _accuserName, string _accEmail, string _accPass, string _accHint, string _accImage )
        {
            accName = _accName;
            accuserName= _accuserName;
            accEmail= _accEmail;
            accPass = _accPass;
            accHint = _accHint;
            accImage = _accImage;
        }

    }
}
