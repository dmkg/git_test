﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PassManageApp
{
    class Account
    {
        int accKey;
        string accName;
        string accUserName;
        string accEmail;
        string accPass;
        string accHint;
        string accImage;

         //access to different account type
        //
        
        public Account( int _accKey, string _accName ,string _accUserName, string _accEmail, string _accPass, string _accHint, string _accImage )
        {
            accKey = _accKey;
            accName = _accName;
            accUserName= _accUserName;
            accEmail= _accEmail;
            accPass = _accPass;
            accHint = _accHint;
            accImage = _accImage;
        }
        public Account() { }

        public int AccKey { get {return accKey;} set {accKey = value;}  }
        public string AccName { get { return accName; } set { accName = value; } }
        public string AccUserName { get { return accUserName; } set { accUserName = value; } }
        public string AccEmail { get { return accEmail; } set { accEmail = value; } }
        public string AccPass { get { return accPass; } set { accPass = value; } }
        public string AccHint { get { return accHint; } set { accHint = value; } }
        public string AccImage { get { return accImage; } set { accImage = value; } }
        

        public string[] getAccValues()
        {
            string[] arrAccValues = { Convert.ToString(accKey), accName, accUserName, accEmail, accPass, accHint, accImage };
            
            return arrAccValues;
        }

    }
}
