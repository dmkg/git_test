﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PassManageApp
{
    class Account
    {
        int accKey;
        string accName;
        string accUserName;
        string accEmail;
        string accPass;
        string accHint;
        string accImage;

        
        public Account( int _accKey, string _accName ,string _accUserName, string _accEmail, string _accPass, string _accHint, string _accImage )
        {
            accKey = _accKey;
            accName = _accName;
            accUserName= _accUserName;
            accEmail= _accEmail;
            accPass = _accPass;
            accHint = _accHint;
            accImage = _accImage;
        }
        public Account() { }

        public int AccKey { get; set; }
        public string AccName { get; set; }
        public string AccUserName { get; set; }
        public string AccEmail { get; set; }
        public string AccPass { get; set; }
        public string AccHint { get; set; }
        public string AccImage { get; set; }

        public string[] getAccValues()
        {
            string[] arrAccValues = { AccName, AccUserName, AccEmail, accPass, accHint, accImage };
            
            return arrAccValues;
        }

    }
}
