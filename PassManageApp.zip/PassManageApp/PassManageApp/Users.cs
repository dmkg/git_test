﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace PassManageApp
{
    
    class User
    {
        public static string fPath = @"C:\Users\DarrenG\Documents\PassManage\";
        //public string useUserFile;
        static string userName;
        static List<Account> listUserAccs;
        static string[] accGroups; //Access to different account type -- Default values: Email, Cellphone, SocialNetwork, Computer,  Bank, Credit Card
        static int[] favorites;
        Account acc;

        

        public User()
        {
            userName = UserName;
           
        }

        public User(string _userName)
        {
            UserName = _userName;
        } 

        public static string UserName { get { return userName; }  set{ userName = value; } }
        public static List<Account> ListUserAccs { get { return listUserAccs; } set { listUserAccs = value; }  }
        public static string[] AccGroups { get { return accGroups; } set { accGroups = value; } }

        public static List<Account> getListUserAccs (int accKey)
        {
            List<Account> newList = ListUserAccs;

            return newList;

        }
        public string[] arrAcc ()
        { return acc.getAccValues(); }

        public void addAcc ()
        {            
            Account acc = new Account();
        }
        
    }
}
