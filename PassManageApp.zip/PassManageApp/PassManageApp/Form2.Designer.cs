﻿
namespace PassManageApp
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_UserSignUp = new System.Windows.Forms.Button();
            this.txtb_UserPasswordSU = new System.Windows.Forms.TextBox();
            this.txtb_UsernameSU = new System.Windows.Forms.TextBox();
            this.lbl_UserPasswordSU = new System.Windows.Forms.Label();
            this.lbl_UserNameSU = new System.Windows.Forms.Label();
            this.txtb_RepeatPsw = new System.Windows.Forms.TextBox();
            this.lbl_RepeatPsw = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_UserSignUp
            // 
            this.btn_UserSignUp.Location = new System.Drawing.Point(82, 323);
            this.btn_UserSignUp.Name = "btn_UserSignUp";
            this.btn_UserSignUp.Size = new System.Drawing.Size(129, 23);
            this.btn_UserSignUp.TabIndex = 10;
            this.btn_UserSignUp.Text = "Sign Up";
            this.btn_UserSignUp.UseVisualStyleBackColor = true;
            this.btn_UserSignUp.Click += new System.EventHandler(this.btn_UserSignUp_Click);
            // 
            // txtb_UserPasswordSU
            // 
            this.txtb_UserPasswordSU.Location = new System.Drawing.Point(82, 215);
            this.txtb_UserPasswordSU.Name = "txtb_UserPasswordSU";
            this.txtb_UserPasswordSU.Size = new System.Drawing.Size(129, 23);
            this.txtb_UserPasswordSU.TabIndex = 9;
            // 
            // txtb_UsernameSU
            // 
            this.txtb_UsernameSU.Location = new System.Drawing.Point(82, 162);
            this.txtb_UsernameSU.Name = "txtb_UsernameSU";
            this.txtb_UsernameSU.Size = new System.Drawing.Size(129, 23);
            this.txtb_UsernameSU.TabIndex = 8;
            // 
            // lbl_UserPasswordSU
            // 
            this.lbl_UserPasswordSU.AutoSize = true;
            this.lbl_UserPasswordSU.Location = new System.Drawing.Point(82, 197);
            this.lbl_UserPasswordSU.Name = "lbl_UserPasswordSU";
            this.lbl_UserPasswordSU.Size = new System.Drawing.Size(57, 15);
            this.lbl_UserPasswordSU.TabIndex = 7;
            this.lbl_UserPasswordSU.Text = "Password";
            // 
            // lbl_UserNameSU
            // 
            this.lbl_UserNameSU.AutoSize = true;
            this.lbl_UserNameSU.Location = new System.Drawing.Point(82, 144);
            this.lbl_UserNameSU.Name = "lbl_UserNameSU";
            this.lbl_UserNameSU.Size = new System.Drawing.Size(60, 15);
            this.lbl_UserNameSU.TabIndex = 6;
            this.lbl_UserNameSU.Text = "Username";
            // 
            // txtb_RepeatPsw
            // 
            this.txtb_RepeatPsw.Location = new System.Drawing.Point(82, 272);
            this.txtb_RepeatPsw.Name = "txtb_RepeatPsw";
            this.txtb_RepeatPsw.Size = new System.Drawing.Size(129, 23);
            this.txtb_RepeatPsw.TabIndex = 12;
            // 
            // lbl_RepeatPsw
            // 
            this.lbl_RepeatPsw.AutoSize = true;
            this.lbl_RepeatPsw.Location = new System.Drawing.Point(82, 254);
            this.lbl_RepeatPsw.Name = "lbl_RepeatPsw";
            this.lbl_RepeatPsw.Size = new System.Drawing.Size(96, 15);
            this.lbl_RepeatPsw.TabIndex = 11;
            this.lbl_RepeatPsw.Text = "Repeat Password";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(294, 450);
            this.Controls.Add(this.txtb_RepeatPsw);
            this.Controls.Add(this.lbl_RepeatPsw);
            this.Controls.Add(this.btn_UserSignUp);
            this.Controls.Add(this.txtb_UserPasswordSU);
            this.Controls.Add(this.txtb_UsernameSU);
            this.Controls.Add(this.lbl_UserPasswordSU);
            this.Controls.Add(this.lbl_UserNameSU);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximumSize = new System.Drawing.Size(314, 493);
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sign Up";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_UserSignUp;
        private System.Windows.Forms.TextBox txtb_UserPasswordSU;
        private System.Windows.Forms.TextBox txtb_UsernameSU;
        private System.Windows.Forms.Label lbl_UserPasswordSU;
        private System.Windows.Forms.Label lbl_UserNameSU;
        private System.Windows.Forms.TextBox txtb_RepeatPsw;
        private System.Windows.Forms.Label lbl_RepeatPsw;
    }
}