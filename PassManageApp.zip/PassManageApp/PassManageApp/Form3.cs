﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace PassManageApp
{
    public partial class Form3 : Form
    {
        
        public Form3()
        {
            InitializeComponent();
            menu_UserName.Text = User.UserName;
            listb_userAccs.Items.Add(User.UserName + "......");// + User.DictUserAccs[0]); ; ;
            
        }
        
        private void btn_UserSignUp1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 f2 = new Form2();
            f2.ShowDialog();
            this.Close();
        }
                
    }
}
