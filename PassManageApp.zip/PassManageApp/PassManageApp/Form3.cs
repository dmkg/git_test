﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace PassManageApp
{
    public partial class Form3 : Form
    {
        
        public Form3()
        {
            InitializeComponent();

            //StringBuilder strBuild = new StringBuilder();
            //Random rnd = new Random();
            //char rLetter;
            //string rndPsw = "";           
            

            menu_UserName.Text = User.UserName;            
            foreach( Account item in User.getListUserAccs(1))
            {                
                listb_userAccs.Items.Add(item.AccKey+"......"+item.AccName);
            }
            textB_InfoUserName.ReadOnly = textB_InfoEmail.ReadOnly = textB_InfoPsw.ReadOnly =
                textB_InfoPswHint.ReadOnly = textB_InfoNotes.ReadOnly =  true;
            btn_InfoEditSave.Text = "Edit";

        }
        private void listb_userAccs_SelectedIndexChanged(object sender, EventArgs e)
        {
            //string.IsNullOrEmpty(subs1[5]) ? User.fPath + @"images\" + "default.png" : User.fPath + @"images\" +

            textB_InfoUserName.Text = User.ListUserAccs[listb_userAccs.SelectedIndex].AccUserName;
            textB_InfoEmail.Text = User.ListUserAccs[listb_userAccs.SelectedIndex].AccEmail;
            textB_InfoPsw.Text = User.ListUserAccs[listb_userAccs.SelectedIndex].AccPass;
            textB_InfoPswHint.Text = User.ListUserAccs[listb_userAccs.SelectedIndex].AccHint;
            textB_InfoNotes.Text = User.ListUserAccs[listb_userAccs.SelectedIndex].AccNotes;
            picb_AccImg.ImageLocation = string.IsNullOrEmpty(User.ListUserAccs[listb_userAccs.SelectedIndex].AccImage) ? User.fPath + @"images\" + "default.png" : User.fPath + @"images\" +
                User.ListUserAccs[listb_userAccs.SelectedIndex].AccImage;

            
        }

        private void btn_InfoEditSave_Click(object sender, EventArgs e)
        {
            if (btn_InfoEditSave.Text == "Edit")
            {
                textB_InfoUserName.ReadOnly = textB_InfoEmail.ReadOnly = textB_InfoPsw.ReadOnly =
                    textB_InfoPswHint.ReadOnly = textB_InfoNotes.ReadOnly = false;

                textB_InfoUserName.BackColor = textB_InfoEmail.BackColor = textB_InfoPsw.BackColor =
                textB_InfoPswHint.BackColor = textB_InfoNotes.BackColor = Color.FromArgb(230, 238, 252);
                btn_InfoEditSave.Text = "Save";
            }
            else
            {
                User.ListUserAccs[listb_userAccs.SelectedIndex].AccUserName = textB_InfoUserName.Text;
                User.ListUserAccs[listb_userAccs.SelectedIndex].AccEmail = textB_InfoEmail.Text;
                User.ListUserAccs[listb_userAccs.SelectedIndex].AccPass = textB_InfoPsw.Text;
                User.ListUserAccs[listb_userAccs.SelectedIndex].AccHint = textB_InfoPswHint.Text;
                User.ListUserAccs[listb_userAccs.SelectedIndex].AccNotes = textB_InfoNotes.Text;
                
                //User.ListUserAccs[listb_userAccs.SelectedIndex].AccImage = picb_AccImg.ImageLocation;



                textB_InfoUserName.ReadOnly = textB_InfoEmail.ReadOnly = textB_InfoPsw.ReadOnly =
                    textB_InfoPswHint.ReadOnly = textB_InfoNotes.ReadOnly = true;
                textB_InfoUserName.BackColor = textB_InfoEmail.BackColor = textB_InfoPsw.BackColor =
                textB_InfoPswHint.BackColor = textB_InfoNotes.BackColor = Color.FromArgb(170, 178, 192);

                btn_InfoEditSave.Text = "Edit";

            }
        }

        private void btn_UserSignUp1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 f2 = new Form2();
            f2.ShowDialog();
            this.Close();
        }

        private void signOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f1 = new Form1();
            f1.ShowDialog();
            this.Close();
        }

        private void infoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //User.ListUserAccs;
            
            using (StreamWriter writer = new StreamWriter(User.fPath+@"user_files\" +User.UserName+".txt"))
            {
                foreach( var item in User.ListUserAccs)
                {
                    writer.WriteLine(
                        item.AccName + ";" +
                        item.AccUserName + ";" +
                        item.AccEmail + ";" +
                        item.AccPass + ";"+
                        item.AccHint + ";"+
                        item.AccImage +";"+
                        item.AccNotes +";"+
                        Convert.ToString(item.AccKey)
                        );
                }
                
            }
        }
    }
}
