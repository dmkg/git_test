﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace PassManageApp
{
    public partial class Form3 : Form
    {
        
        public Form3()
        {
            InitializeComponent();

            //StringBuilder strBuild = new StringBuilder();
            //Random rnd = new Random();
            //char rLetter;
            //string rndPsw = "";           

            menu_UserName.Text = User.UserName;            
            foreach( Account item in User.getListUserAccs(1))
            {                
                listb_userAccs.Items.Add(item.AccKey+"......"+item.AccName);
            }
            textB_InfoUserName.ReadOnly = textB_InfoEmail.ReadOnly = textB_InfoPsw.ReadOnly =
                textB_InfoPswHint.ReadOnly = textB_InfoNotes.ReadOnly =  true;
            btn_InfoEditSave.Text = "Edit";

        }
        private void listb_userAccs_SelectedIndexChanged(object sender, EventArgs e)
        {
            textB_InfoUserName.Text = User.ListUserAccs[listb_userAccs.SelectedIndex].AccUserName;
            textB_InfoEmail.Text = User.ListUserAccs[listb_userAccs.SelectedIndex].AccEmail;
            textB_InfoPsw.Text = User.ListUserAccs[listb_userAccs.SelectedIndex].AccPass;
            textB_InfoPswHint.Text = User.ListUserAccs[listb_userAccs.SelectedIndex].AccHint;
            textB_InfoNotes.Text = User.ListUserAccs[listb_userAccs.SelectedIndex].AccNotes;
            picb_AccImg.ImageLocation = User.ListUserAccs[listb_userAccs.SelectedIndex].AccImage;


        }

        private void btn_InfoEditSave_Click(object sender, EventArgs e)
        {
            if (btn_InfoEditSave.Text == "Edit")
            {
                textB_InfoUserName.ReadOnly = textB_InfoEmail.ReadOnly = textB_InfoPsw.ReadOnly =
                    textB_InfoPswHint.ReadOnly = textB_InfoNotes.ReadOnly = false;

                textB_InfoUserName.BackColor = textB_InfoEmail.BackColor = textB_InfoPsw.BackColor =
                textB_InfoPswHint.BackColor = textB_InfoNotes.BackColor = Color.FromArgb(230, 238, 252);
                btn_InfoEditSave.Text = "Save";
            }
            else
            {
                textB_InfoUserName.ReadOnly = textB_InfoEmail.ReadOnly = textB_InfoPsw.ReadOnly =
                    textB_InfoPswHint.ReadOnly = textB_InfoNotes.ReadOnly = true;
                textB_InfoUserName.BackColor = textB_InfoEmail.BackColor = textB_InfoPsw.BackColor =
                textB_InfoPswHint.BackColor = textB_InfoNotes.BackColor = Color.FromArgb(170, 178, 192);

                btn_InfoEditSave.Text = "Edit";
            }
        }

        private void btn_UserSignUp1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 f2 = new Form2();
            f2.ShowDialog();
            this.Close();
        }

        private void signOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f1 = new Form1();
            f1.ShowDialog();
            this.Close();
        }

        
    }
}
