﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace PassManageApp
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btn_UserSignUp_Click(object sender, EventArgs e)
        {
            // Create a text string
            string checkUsers = File.ReadAllText(@"C:\Users\DarrenG\Documents\PassManage\users.txt");  // Create a file and write the content of writeText to it
            int count = 0;
            string line;
            var sr = new StringReader(checkUsers);

            while ((line = sr.ReadLine()) != null)
            {
                count++;
                Console.WriteLine(count);
            }
        }
    }
}
