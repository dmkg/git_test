﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PassManageApp
{
    
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent(); 
        }

        private void btn_UserLogin_Click(object sender, EventArgs e)
        {
            //C:\Users\Zole\Documents\PassManage  C:\Users\DarrenG\Documents\PassManage\users.txt
            string checkUsers = File.ReadAllText(@"C:\Users\DarrenG\Documents\PassManage\users.txt");  // Create a file and write the content of writeText to it
            int count1 = 0;
            int count2 = 0;
            string result2 = "";
            var sr = new StringReader(checkUsers);
            string line,line1, checkUserName ="", checkPass, result;
            
            lbl_MessageLogin.ForeColor = Color.Red;
            result = "Wrong username or password!";
            
            User.ListUserAccs = new List<Account>();
            if (string.IsNullOrEmpty(txtb_Username.Text) && string.IsNullOrEmpty(txtb_UserPassword.Text))
            { result = "Input username and password!"; }
            else
            {
                while ((line = sr.ReadLine()) != null)
                {
                    count1++;
                    string[] subs = line.Split('\t');
                    checkUserName = subs[0];
                    checkPass = subs[1];

                    if (checkUserName == txtb_Username.Text && checkPass == txtb_UserPassword.Text)
                    {
                        lbl_MessageLogin.ForeColor = Color.Green;
                        result = "Login succesful!";

                        User newUser = new User();
                        
                        User.UserName = checkUserName;

                        string checkUserFile = User.fPath + @"user_files\" + checkUserName + ".txt";
                        
                        using (StreamReader srUF = new StreamReader(checkUserFile))
                        {

                            string accName, accUserName, accEmail, accPass, accHint, accImage, accNotes;
                            int accKey;
                            string[] subs1 = new string[7];
                            count2 = 0;
                            while ((line1 = srUF.ReadLine()) != null)
                            {
                                subs1 = line1.Split(';');
                                count2++;
                                accName = subs1[0];
                                accUserName = subs1[1];
                                accEmail = subs1[2];
                                accPass = subs1[3];
                                accHint = subs1[4];
                                accImage = string.IsNullOrEmpty(subs1[5]) ? User.fPath + @"images\" + "default.png" : User.fPath + @"images\" + subs1[5];
                                accNotes = subs1[6];

                                accKey = Convert.ToInt32(subs1[7]);                                

                                Account acc = new Account(accKey, accName, accUserName, accEmail, accPass, accHint, accImage, accNotes);
                                
                                User.ListUserAccs.Add(acc);
                            }
                           
                            result2 = "";
                            foreach (var item in User.ListUserAccs)
                            {
                                result2 += item.AccName + "\n";
                            }

                            this.Hide();
                            Form3 f3 = new Form3();
                            f3.ShowDialog();
                            this.Close();
                        }
                    }
                }
            }
            
            lbl_MessageLogin.Text = result;
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {             
                //exit application when form is closed
                Application.Exit();
            
        }
    }
}
