﻿
namespace PassManageApp
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            this.leftSideB = new System.Windows.Forms.Panel();
            this.picAcc = new System.Windows.Forms.PictureBox();
            this.leftSideB.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picAcc)).BeginInit();
            this.SuspendLayout();
            // 
            // leftSideB
            // 
            this.leftSideB.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(48)))), ((int)(((byte)(72)))));
            this.leftSideB.Controls.Add(this.picAcc);
            this.leftSideB.Location = new System.Drawing.Point(-2, -1);
            this.leftSideB.Name = "leftSideB";
            this.leftSideB.Size = new System.Drawing.Size(152, 451);
            this.leftSideB.TabIndex = 0;
            // 
            // picAcc
            // 
            this.picAcc.Image = ((System.Drawing.Image)(resources.GetObject("picAcc.Image")));
            this.picAcc.Location = new System.Drawing.Point(14, 13);
            this.picAcc.Name = "picAcc";
            this.picAcc.Size = new System.Drawing.Size(37, 33);
            this.picAcc.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picAcc.TabIndex = 0;
            this.picAcc.TabStop = false;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.leftSideB);
            this.Name = "Form3";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Pass Manage";
            this.leftSideB.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picAcc)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel leftSideB;
        private System.Windows.Forms.PictureBox picAcc;
    }
}