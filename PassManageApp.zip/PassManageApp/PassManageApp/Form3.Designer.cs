﻿
namespace PassManageApp
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            this.pan_leftSideB = new System.Windows.Forms.Panel();
            this.pan_leftSideList1 = new System.Windows.Forms.Panel();
            this.picAcc = new System.Windows.Forms.PictureBox();
            this.menu_User = new System.Windows.Forms.MenuStrip();
            this.menu_UserName = new System.Windows.Forms.ToolStripMenuItem();
            this.infoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.signOutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pan_central = new System.Windows.Forms.Panel();
            this.listb_userAccs = new System.Windows.Forms.ListBox();
            this.pan_leftSideB.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picAcc)).BeginInit();
            this.menu_User.SuspendLayout();
            this.pan_central.SuspendLayout();
            this.SuspendLayout();
            // 
            // pan_leftSideB
            // 
            this.pan_leftSideB.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(48)))), ((int)(((byte)(72)))));
            this.pan_leftSideB.Controls.Add(this.pan_leftSideList1);
            this.pan_leftSideB.Controls.Add(this.picAcc);
            this.pan_leftSideB.Controls.Add(this.menu_User);
            this.pan_leftSideB.Font = new System.Drawing.Font("Sitka Display", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.pan_leftSideB.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.pan_leftSideB.Location = new System.Drawing.Point(-2, -1);
            this.pan_leftSideB.Name = "pan_leftSideB";
            this.pan_leftSideB.Size = new System.Drawing.Size(225, 451);
            this.pan_leftSideB.TabIndex = 0;
            // 
            // pan_leftSideList1
            // 
            this.pan_leftSideList1.Location = new System.Drawing.Point(14, 71);
            this.pan_leftSideList1.Name = "pan_leftSideList1";
            this.pan_leftSideList1.Size = new System.Drawing.Size(200, 100);
            this.pan_leftSideList1.TabIndex = 2;
            // 
            // picAcc
            // 
            this.picAcc.Image = ((System.Drawing.Image)(resources.GetObject("picAcc.Image")));
            this.picAcc.Location = new System.Drawing.Point(14, 13);
            this.picAcc.Name = "picAcc";
            this.picAcc.Size = new System.Drawing.Size(37, 33);
            this.picAcc.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picAcc.TabIndex = 0;
            this.picAcc.TabStop = false;
            // 
            // menu_User
            // 
            this.menu_User.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(48)))), ((int)(((byte)(74)))));
            this.menu_User.Dock = System.Windows.Forms.DockStyle.None;
            this.menu_User.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menu_UserName});
            this.menu_User.Location = new System.Drawing.Point(54, 13);
            this.menu_User.Name = "menu_User";
            this.menu_User.Size = new System.Drawing.Size(20, 24);
            this.menu_User.TabIndex = 1;
            this.menu_User.Text = "menuStrip1";
            // 
            // menu_UserName
            // 
            this.menu_UserName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            this.menu_UserName.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.infoToolStripMenuItem,
            this.signOutToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.menu_UserName.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.menu_UserName.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.menu_UserName.Name = "menu_UserName";
            this.menu_UserName.Size = new System.Drawing.Size(12, 20);
            // 
            // infoToolStripMenuItem
            // 
            this.infoToolStripMenuItem.Name = "infoToolStripMenuItem";
            this.infoToolStripMenuItem.Size = new System.Drawing.Size(141, 26);
            this.infoToolStripMenuItem.Text = "Info";
            // 
            // signOutToolStripMenuItem
            // 
            this.signOutToolStripMenuItem.Name = "signOutToolStripMenuItem";
            this.signOutToolStripMenuItem.Size = new System.Drawing.Size(141, 26);
            this.signOutToolStripMenuItem.Text = "Sign Out";
            this.signOutToolStripMenuItem.Click += new System.EventHandler(this.signOutToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(141, 26);
            this.exitToolStripMenuItem.Text = "Exit";
            // 
            // pan_central
            // 
            this.pan_central.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.pan_central.Controls.Add(this.listb_userAccs);
            this.pan_central.Location = new System.Drawing.Point(221, -1);
            this.pan_central.Name = "pan_central";
            this.pan_central.Size = new System.Drawing.Size(289, 451);
            this.pan_central.TabIndex = 1;
            // 
            // listb_userAccs
            // 
            this.listb_userAccs.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.listb_userAccs.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(45)))), ((int)(((byte)(57)))));
            this.listb_userAccs.FormattingEnabled = true;
            this.listb_userAccs.ItemHeight = 21;
            this.listb_userAccs.Location = new System.Drawing.Point(3, 60);
            this.listb_userAccs.Name = "listb_userAccs";
            this.listb_userAccs.Size = new System.Drawing.Size(224, 319);
            this.listb_userAccs.TabIndex = 0;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pan_central);
            this.Controls.Add(this.pan_leftSideB);
            this.MainMenuStrip = this.menu_User;
            this.Name = "Form3";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Pass Manage";
            this.pan_leftSideB.ResumeLayout(false);
            this.pan_leftSideB.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picAcc)).EndInit();
            this.menu_User.ResumeLayout(false);
            this.menu_User.PerformLayout();
            this.pan_central.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pan_leftSideB;
        private System.Windows.Forms.PictureBox picAcc;
        private System.Windows.Forms.MenuStrip menu_User;
        private System.Windows.Forms.ToolStripMenuItem menu_UserName;
        private System.Windows.Forms.ToolStripMenuItem infoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem signOutToolStripMenuItem;
        private System.Windows.Forms.Panel pan_central;
        private System.Windows.Forms.ListBox listb_userAccs;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.Panel pan_leftSideList1;
    }
}