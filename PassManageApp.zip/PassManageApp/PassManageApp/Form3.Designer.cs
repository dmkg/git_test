﻿
namespace PassManageApp
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            this.pan_leftSideB = new System.Windows.Forms.Panel();
            this.pan_leftSideList1 = new System.Windows.Forms.Panel();
            this.btn_All = new FontAwesome.Sharp.IconButton();
            this.btn_Archive = new FontAwesome.Sharp.IconButton();
            this.btn_Active = new FontAwesome.Sharp.IconButton();
            this.btn_Recent = new FontAwesome.Sharp.IconButton();
            this.btn_Favorites = new FontAwesome.Sharp.IconButton();
            this.picAcc = new System.Windows.Forms.PictureBox();
            this.menu_User = new System.Windows.Forms.MenuStrip();
            this.menu_UserName = new System.Windows.Forms.ToolStripMenuItem();
            this.infoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.signOutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pan_central = new System.Windows.Forms.Panel();
            this.listb_userAccs = new System.Windows.Forms.ListBox();
            this.pan_Right = new System.Windows.Forms.Panel();
            this.btn_InfoEditSave = new System.Windows.Forms.Button();
            this.textB_InfoNotes = new System.Windows.Forms.TextBox();
            this.lbl_InfoNotes = new System.Windows.Forms.Label();
            this.textB_InfoEmail = new System.Windows.Forms.TextBox();
            this.textB_InfoPswHint = new System.Windows.Forms.TextBox();
            this.textB_InfoPsw = new System.Windows.Forms.TextBox();
            this.textB_InfoUserName = new System.Windows.Forms.TextBox();
            this.lbl_InfoEmail = new System.Windows.Forms.Label();
            this.lbl__InfoPswHint = new System.Windows.Forms.Label();
            this.lbl_InfoPsw = new System.Windows.Forms.Label();
            this.lbl_InfoUserName = new System.Windows.Forms.Label();
            this.picb_AccImg = new System.Windows.Forms.PictureBox();
            this.pan_leftSideB.SuspendLayout();
            this.pan_leftSideList1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picAcc)).BeginInit();
            this.menu_User.SuspendLayout();
            this.pan_central.SuspendLayout();
            this.pan_Right.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picb_AccImg)).BeginInit();
            this.SuspendLayout();
            // 
            // pan_leftSideB
            // 
            this.pan_leftSideB.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(48)))), ((int)(((byte)(72)))));
            this.pan_leftSideB.Controls.Add(this.pan_leftSideList1);
            this.pan_leftSideB.Controls.Add(this.picAcc);
            this.pan_leftSideB.Controls.Add(this.menu_User);
            this.pan_leftSideB.Font = new System.Drawing.Font("Sitka Display", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.pan_leftSideB.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.pan_leftSideB.Location = new System.Drawing.Point(-2, -1);
            this.pan_leftSideB.Name = "pan_leftSideB";
            this.pan_leftSideB.Size = new System.Drawing.Size(252, 511);
            this.pan_leftSideB.TabIndex = 0;
            // 
            // pan_leftSideList1
            // 
            this.pan_leftSideList1.Controls.Add(this.btn_All);
            this.pan_leftSideList1.Controls.Add(this.btn_Archive);
            this.pan_leftSideList1.Controls.Add(this.btn_Active);
            this.pan_leftSideList1.Controls.Add(this.btn_Recent);
            this.pan_leftSideList1.Controls.Add(this.btn_Favorites);
            this.pan_leftSideList1.Font = new System.Drawing.Font("Sitka Display", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.pan_leftSideList1.Location = new System.Drawing.Point(16, 95);
            this.pan_leftSideList1.Name = "pan_leftSideList1";
            this.pan_leftSideList1.Size = new System.Drawing.Size(182, 204);
            this.pan_leftSideList1.TabIndex = 2;
            // 
            // btn_All
            // 
            this.btn_All.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_All.FlatAppearance.BorderSize = 0;
            this.btn_All.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_All.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_All.ForeColor = System.Drawing.Color.Gainsboro;
            this.btn_All.IconChar = FontAwesome.Sharp.IconChar.LayerGroup;
            this.btn_All.IconColor = System.Drawing.Color.Gainsboro;
            this.btn_All.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btn_All.IconSize = 32;
            this.btn_All.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_All.Location = new System.Drawing.Point(0, 148);
            this.btn_All.Name = "btn_All";
            this.btn_All.Size = new System.Drawing.Size(182, 37);
            this.btn_All.TabIndex = 4;
            this.btn_All.Text = "All";
            this.btn_All.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_All.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_All.UseVisualStyleBackColor = true;
            // 
            // btn_Archive
            // 
            this.btn_Archive.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Archive.FlatAppearance.BorderSize = 0;
            this.btn_Archive.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Archive.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_Archive.ForeColor = System.Drawing.Color.Gainsboro;
            this.btn_Archive.IconChar = FontAwesome.Sharp.IconChar.Archive;
            this.btn_Archive.IconColor = System.Drawing.Color.Gainsboro;
            this.btn_Archive.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btn_Archive.IconSize = 32;
            this.btn_Archive.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Archive.Location = new System.Drawing.Point(0, 111);
            this.btn_Archive.Name = "btn_Archive";
            this.btn_Archive.Size = new System.Drawing.Size(182, 37);
            this.btn_Archive.TabIndex = 3;
            this.btn_Archive.Text = "Archive";
            this.btn_Archive.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Archive.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_Archive.UseVisualStyleBackColor = true;
            // 
            // btn_Active
            // 
            this.btn_Active.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Active.FlatAppearance.BorderSize = 0;
            this.btn_Active.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Active.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_Active.ForeColor = System.Drawing.Color.Gainsboro;
            this.btn_Active.IconChar = FontAwesome.Sharp.IconChar.Running;
            this.btn_Active.IconColor = System.Drawing.Color.Gainsboro;
            this.btn_Active.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btn_Active.IconSize = 32;
            this.btn_Active.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Active.Location = new System.Drawing.Point(0, 74);
            this.btn_Active.Name = "btn_Active";
            this.btn_Active.Size = new System.Drawing.Size(182, 37);
            this.btn_Active.TabIndex = 2;
            this.btn_Active.Text = "Active";
            this.btn_Active.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Active.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_Active.UseVisualStyleBackColor = true;
            // 
            // btn_Recent
            // 
            this.btn_Recent.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Recent.FlatAppearance.BorderSize = 0;
            this.btn_Recent.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Recent.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_Recent.ForeColor = System.Drawing.Color.Gainsboro;
            this.btn_Recent.IconChar = FontAwesome.Sharp.IconChar.Clock;
            this.btn_Recent.IconColor = System.Drawing.Color.Gainsboro;
            this.btn_Recent.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btn_Recent.IconSize = 32;
            this.btn_Recent.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Recent.Location = new System.Drawing.Point(0, 37);
            this.btn_Recent.Name = "btn_Recent";
            this.btn_Recent.Size = new System.Drawing.Size(182, 37);
            this.btn_Recent.TabIndex = 1;
            this.btn_Recent.Text = "Recent";
            this.btn_Recent.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Recent.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_Recent.UseVisualStyleBackColor = true;
            // 
            // btn_Favorites
            // 
            this.btn_Favorites.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Favorites.FlatAppearance.BorderSize = 0;
            this.btn_Favorites.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Favorites.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_Favorites.ForeColor = System.Drawing.Color.Gainsboro;
            this.btn_Favorites.IconChar = FontAwesome.Sharp.IconChar.Crown;
            this.btn_Favorites.IconColor = System.Drawing.Color.Gainsboro;
            this.btn_Favorites.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btn_Favorites.IconSize = 32;
            this.btn_Favorites.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Favorites.Location = new System.Drawing.Point(0, 0);
            this.btn_Favorites.Name = "btn_Favorites";
            this.btn_Favorites.Size = new System.Drawing.Size(182, 37);
            this.btn_Favorites.TabIndex = 0;
            this.btn_Favorites.Text = "Favorites";
            this.btn_Favorites.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Favorites.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_Favorites.UseVisualStyleBackColor = true;
            // 
            // picAcc
            // 
            this.picAcc.Image = ((System.Drawing.Image)(resources.GetObject("picAcc.Image")));
            this.picAcc.Location = new System.Drawing.Point(16, 15);
            this.picAcc.Name = "picAcc";
            this.picAcc.Size = new System.Drawing.Size(42, 37);
            this.picAcc.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picAcc.TabIndex = 0;
            this.picAcc.TabStop = false;
            // 
            // menu_User
            // 
            this.menu_User.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(48)))), ((int)(((byte)(74)))));
            this.menu_User.Dock = System.Windows.Forms.DockStyle.None;
            this.menu_User.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menu_UserName});
            this.menu_User.Location = new System.Drawing.Point(62, 15);
            this.menu_User.Name = "menu_User";
            this.menu_User.Padding = new System.Windows.Forms.Padding(7, 2, 0, 2);
            this.menu_User.Size = new System.Drawing.Size(21, 24);
            this.menu_User.TabIndex = 1;
            this.menu_User.Text = "menuStrip1";
            // 
            // menu_UserName
            // 
            this.menu_UserName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            this.menu_UserName.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.infoToolStripMenuItem,
            this.signOutToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.menu_UserName.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.menu_UserName.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.menu_UserName.Name = "menu_UserName";
            this.menu_UserName.Size = new System.Drawing.Size(12, 20);
            // 
            // infoToolStripMenuItem
            // 
            this.infoToolStripMenuItem.Name = "infoToolStripMenuItem";
            this.infoToolStripMenuItem.Size = new System.Drawing.Size(141, 26);
            this.infoToolStripMenuItem.Text = "Save";
            // 
            // signOutToolStripMenuItem
            // 
            this.signOutToolStripMenuItem.Name = "signOutToolStripMenuItem";
            this.signOutToolStripMenuItem.Size = new System.Drawing.Size(141, 26);
            this.signOutToolStripMenuItem.Text = "Sign Out";
            this.signOutToolStripMenuItem.Click += new System.EventHandler(this.signOutToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(141, 26);
            this.exitToolStripMenuItem.Text = "Exit";
            // 
            // pan_central
            // 
            this.pan_central.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.pan_central.Controls.Add(this.listb_userAccs);
            this.pan_central.Location = new System.Drawing.Point(253, -1);
            this.pan_central.Name = "pan_central";
            this.pan_central.Size = new System.Drawing.Size(268, 508);
            this.pan_central.TabIndex = 1;
            // 
            // listb_userAccs
            // 
            this.listb_userAccs.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.listb_userAccs.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(45)))), ((int)(((byte)(57)))));
            this.listb_userAccs.FormattingEnabled = true;
            this.listb_userAccs.ItemHeight = 21;
            this.listb_userAccs.Location = new System.Drawing.Point(3, 68);
            this.listb_userAccs.Name = "listb_userAccs";
            this.listb_userAccs.Size = new System.Drawing.Size(255, 361);
            this.listb_userAccs.TabIndex = 0;
            this.listb_userAccs.SelectedIndexChanged += new System.EventHandler(this.listb_userAccs_SelectedIndexChanged);
            // 
            // pan_Right
            // 
            this.pan_Right.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(188)))), ((int)(((byte)(202)))));
            this.pan_Right.Controls.Add(this.btn_InfoEditSave);
            this.pan_Right.Controls.Add(this.textB_InfoNotes);
            this.pan_Right.Controls.Add(this.lbl_InfoNotes);
            this.pan_Right.Controls.Add(this.textB_InfoEmail);
            this.pan_Right.Controls.Add(this.textB_InfoPswHint);
            this.pan_Right.Controls.Add(this.textB_InfoPsw);
            this.pan_Right.Controls.Add(this.textB_InfoUserName);
            this.pan_Right.Controls.Add(this.lbl_InfoEmail);
            this.pan_Right.Controls.Add(this.lbl__InfoPswHint);
            this.pan_Right.Controls.Add(this.lbl_InfoPsw);
            this.pan_Right.Controls.Add(this.lbl_InfoUserName);
            this.pan_Right.Controls.Add(this.picb_AccImg);
            this.pan_Right.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.pan_Right.Location = new System.Drawing.Point(527, -1);
            this.pan_Right.Name = "pan_Right";
            this.pan_Right.Size = new System.Drawing.Size(375, 511);
            this.pan_Right.TabIndex = 2;
            // 
            // btn_InfoEditSave
            // 
            this.btn_InfoEditSave.Location = new System.Drawing.Point(222, 53);
            this.btn_InfoEditSave.Name = "btn_InfoEditSave";
            this.btn_InfoEditSave.Size = new System.Drawing.Size(75, 23);
            this.btn_InfoEditSave.TabIndex = 11;
            this.btn_InfoEditSave.Text = "Edit";
            this.btn_InfoEditSave.UseVisualStyleBackColor = true;
            this.btn_InfoEditSave.Click += new System.EventHandler(this.btn_InfoEditSave_Click);
            // 
            // textB_InfoNotes
            // 
            this.textB_InfoNotes.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(178)))), ((int)(((byte)(192)))));
            this.textB_InfoNotes.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textB_InfoNotes.Location = new System.Drawing.Point(22, 317);
            this.textB_InfoNotes.Multiline = true;
            this.textB_InfoNotes.Name = "textB_InfoNotes";
            this.textB_InfoNotes.Size = new System.Drawing.Size(322, 155);
            this.textB_InfoNotes.TabIndex = 10;
            // 
            // lbl_InfoNotes
            // 
            this.lbl_InfoNotes.AutoSize = true;
            this.lbl_InfoNotes.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_InfoNotes.Location = new System.Drawing.Point(22, 287);
            this.lbl_InfoNotes.Name = "lbl_InfoNotes";
            this.lbl_InfoNotes.Size = new System.Drawing.Size(44, 17);
            this.lbl_InfoNotes.TabIndex = 9;
            this.lbl_InfoNotes.Text = "Notes";
            // 
            // textB_InfoEmail
            // 
            this.textB_InfoEmail.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(178)))), ((int)(((byte)(192)))));
            this.textB_InfoEmail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textB_InfoEmail.Location = new System.Drawing.Point(148, 255);
            this.textB_InfoEmail.Name = "textB_InfoEmail";
            this.textB_InfoEmail.Size = new System.Drawing.Size(196, 25);
            this.textB_InfoEmail.TabIndex = 8;
            // 
            // textB_InfoPswHint
            // 
            this.textB_InfoPswHint.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(178)))), ((int)(((byte)(192)))));
            this.textB_InfoPswHint.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textB_InfoPswHint.Location = new System.Drawing.Point(148, 224);
            this.textB_InfoPswHint.Name = "textB_InfoPswHint";
            this.textB_InfoPswHint.Size = new System.Drawing.Size(196, 25);
            this.textB_InfoPswHint.TabIndex = 7;
            // 
            // textB_InfoPsw
            // 
            this.textB_InfoPsw.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(178)))), ((int)(((byte)(192)))));
            this.textB_InfoPsw.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textB_InfoPsw.Location = new System.Drawing.Point(148, 193);
            this.textB_InfoPsw.Name = "textB_InfoPsw";
            this.textB_InfoPsw.Size = new System.Drawing.Size(196, 25);
            this.textB_InfoPsw.TabIndex = 6;
            // 
            // textB_InfoUserName
            // 
            this.textB_InfoUserName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(178)))), ((int)(((byte)(192)))));
            this.textB_InfoUserName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textB_InfoUserName.Location = new System.Drawing.Point(148, 162);
            this.textB_InfoUserName.Name = "textB_InfoUserName";
            this.textB_InfoUserName.Size = new System.Drawing.Size(196, 25);
            this.textB_InfoUserName.TabIndex = 5;
            // 
            // lbl_InfoEmail
            // 
            this.lbl_InfoEmail.AutoSize = true;
            this.lbl_InfoEmail.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_InfoEmail.Location = new System.Drawing.Point(22, 257);
            this.lbl_InfoEmail.Name = "lbl_InfoEmail";
            this.lbl_InfoEmail.Size = new System.Drawing.Size(40, 17);
            this.lbl_InfoEmail.TabIndex = 4;
            this.lbl_InfoEmail.Text = "Email";
            // 
            // lbl__InfoPswHint
            // 
            this.lbl__InfoPswHint.AutoSize = true;
            this.lbl__InfoPswHint.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl__InfoPswHint.Location = new System.Drawing.Point(22, 226);
            this.lbl__InfoPswHint.Name = "lbl__InfoPswHint";
            this.lbl__InfoPswHint.Size = new System.Drawing.Size(96, 17);
            this.lbl__InfoPswHint.TabIndex = 3;
            this.lbl__InfoPswHint.Text = "Password Hint";
            // 
            // lbl_InfoPsw
            // 
            this.lbl_InfoPsw.AutoSize = true;
            this.lbl_InfoPsw.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_InfoPsw.Location = new System.Drawing.Point(22, 195);
            this.lbl_InfoPsw.Name = "lbl_InfoPsw";
            this.lbl_InfoPsw.Size = new System.Drawing.Size(66, 17);
            this.lbl_InfoPsw.TabIndex = 2;
            this.lbl_InfoPsw.Text = "Password";
            // 
            // lbl_InfoUserName
            // 
            this.lbl_InfoUserName.AutoSize = true;
            this.lbl_InfoUserName.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_InfoUserName.Location = new System.Drawing.Point(22, 165);
            this.lbl_InfoUserName.Name = "lbl_InfoUserName";
            this.lbl_InfoUserName.Size = new System.Drawing.Size(75, 17);
            this.lbl_InfoUserName.TabIndex = 1;
            this.lbl_InfoUserName.Text = "User Name";
            // 
            // picb_AccImg
            // 
            this.picb_AccImg.ImageLocation = "";
            this.picb_AccImg.Location = new System.Drawing.Point(22, 15);
            this.picb_AccImg.Name = "picb_AccImg";
            this.picb_AccImg.Size = new System.Drawing.Size(128, 128);
            this.picb_AccImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picb_AccImg.TabIndex = 0;
            this.picb_AccImg.TabStop = false;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(903, 505);
            this.Controls.Add(this.pan_Right);
            this.Controls.Add(this.pan_central);
            this.Controls.Add(this.pan_leftSideB);
            this.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MainMenuStrip = this.menu_User;
            this.MaximumSize = new System.Drawing.Size(923, 548);
            this.Name = "Form3";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Pass Manage";
            this.pan_leftSideB.ResumeLayout(false);
            this.pan_leftSideB.PerformLayout();
            this.pan_leftSideList1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picAcc)).EndInit();
            this.menu_User.ResumeLayout(false);
            this.menu_User.PerformLayout();
            this.pan_central.ResumeLayout(false);
            this.pan_Right.ResumeLayout(false);
            this.pan_Right.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picb_AccImg)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pan_leftSideB;
        private System.Windows.Forms.PictureBox picAcc;
        private System.Windows.Forms.MenuStrip menu_User;
        private System.Windows.Forms.ToolStripMenuItem menu_UserName;
        private System.Windows.Forms.ToolStripMenuItem infoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem signOutToolStripMenuItem;
        private System.Windows.Forms.Panel pan_central;
        private System.Windows.Forms.ListBox listb_userAccs;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.Panel pan_leftSideList1;
        private FontAwesome.Sharp.IconButton btn_All;
        private FontAwesome.Sharp.IconButton btn_Archive;
        private FontAwesome.Sharp.IconButton btn_Active;
        private FontAwesome.Sharp.IconButton btn_Recent;
        private FontAwesome.Sharp.IconButton btn_Favorites;
        private System.Windows.Forms.Panel pan_Right;
        private System.Windows.Forms.PictureBox picb_AccImg;
        private System.Windows.Forms.Label lbl_InfoUserName;
        private System.Windows.Forms.Label lbl_InfoEmail;
        private System.Windows.Forms.Label lbl__InfoPswHint;
        private System.Windows.Forms.Label lbl_InfoPsw;
        private System.Windows.Forms.TextBox textB_InfoUserName;
        private System.Windows.Forms.TextBox textB_InfoEmail;
        private System.Windows.Forms.TextBox textB_InfoPswHint;
        private System.Windows.Forms.TextBox textB_InfoPsw;
        private System.Windows.Forms.TextBox textB_InfoNotes;
        private System.Windows.Forms.Label lbl_InfoNotes;
        private System.Windows.Forms.Button btn_InfoEditSave;
    }
}